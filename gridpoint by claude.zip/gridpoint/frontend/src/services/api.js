const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

async function handleResponse(res) {
  let data
  try {
    data = await res.json()
  } catch (e) {
    throw new Error('Unexpected server response. Please check that the backend is running.')
  }
  if (!res.ok) {
    throw new Error(data?.error || 'Something went wrong. Please try again.')
  }
  return data
}

export async function fetchDemoData() {
  const res = await fetch(`${BASE_URL}/demo-data`)
  return handleResponse(res)
}

export async function validateData(rows) {
  const res = await fetch(`${BASE_URL}/validate-data`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ rows }),
  })
  return handleResponse(res)
}

export async function optimizeNetwork(params) {
  const res = await fetch(`${BASE_URL}/optimize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  })
  return handleResponse(res)
}

export async function runWhatIf(params) {
  const res = await fetch(`${BASE_URL}/what-if`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  })
  return handleResponse(res)
}
