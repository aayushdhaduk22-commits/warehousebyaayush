import { useState, useCallback } from 'react'
import Papa from 'papaparse'

import Header from './components/Header'
import StatsBar from './components/StatsBar'
import ControlPanel from './components/ControlPanel'
import MapView from './components/MapView'
import HeatmapLegend from './components/HeatmapLegend'
import ResultsPanel from './components/ResultsPanel'
import WarehouseTable from './components/WarehouseTable'
import AssignmentTable from './components/AssignmentTable'
import ComparisonChart from './components/ComparisonChart'
import WhatIfSimulator from './components/WhatIfSimulator'
import ExplainabilityPanel from './components/ExplainabilityPanel'
import AlgorithmPanel from './components/AlgorithmPanel'
import PresentationMode from './components/PresentationMode'

import { fetchDemoData, validateData, optimizeNetwork } from './services/api'

const DEFAULT_CONFIG = {
  warehouses: 3,
  useCapacity: false,
  capacity: '2000',
  useRadius: false,
  maxRadius: '15',
  costPerKm: '25',
  warehouseFixedCost: '50000',
}

export default function App() {
  const [locations, setLocations] = useState([])
  const [config, setConfig] = useState(DEFAULT_CONFIG)
  const [showHeatmap, setShowHeatmap] = useState(true)
  const [result, setResult] = useState(null)
  const [isOptimizing, setIsOptimizing] = useState(false)
  const [error, setError] = useState(null)
  const [notice, setNotice] = useState(null)
  const [selected, setSelected] = useState(null)
  const [presentationMode, setPresentationMode] = useState(false)

  const handleLoadDemo = useCallback(async () => {
    setError(null)
    setNotice(null)
    setResult(null)
    setSelected(null)
    try {
      const data = await fetchDemoData()
      setLocations(data.locations)
    } catch (e) {
      setError(e.message)
    }
  }, [])

  const handleFileSelected = useCallback((file) => {
    setError(null)
    setNotice(null)
    setResult(null)
    setSelected(null)
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: async (parsed) => {
        try {
          const validation = await validateData(parsed.data)
          if (validation.row_count === 0) {
            setError(
              validation.errors?.[0] ||
                'No valid rows found in the CSV. Please check the format: id,name,latitude,longitude,daily_orders'
            )
            return
          }
          setLocations(validation.rows)
          if (validation.summary) {
            setNotice(validation.summary)
          }
        } catch (e) {
          setError(e.message)
        }
      },
      error: () => {
        setError('Could not parse the CSV file. Please check the format and try again.')
      },
    })
  }, [])

  const handleOptimize = useCallback(async () => {
    if (!locations.length) return
    setIsOptimizing(true)
    setError(null)
    try {
      const payload = {
        locations,
        warehouses: config.warehouses,
        use_capacity: config.useCapacity,
        capacity: config.useCapacity ? parseFloat(config.capacity) || null : null,
        use_radius: config.useRadius,
        max_radius: config.useRadius ? parseFloat(config.maxRadius) || null : null,
        cost_per_km: parseFloat(config.costPerKm) || 25,
        warehouse_fixed_cost: parseFloat(config.warehouseFixedCost) || 50000,
      }
      const data = await optimizeNetwork(payload)
      setResult(data)
      setSelected(null)
    } catch (e) {
      setError(e.message)
    } finally {
      setIsOptimizing(false)
    }
  }, [locations, config])

  const totalOrders = locations.reduce((s, l) => s + Number(l.daily_orders || 0), 0)

  if (presentationMode) {
    return (
      <PresentationMode
        result={result}
        warehouseCount={config.warehouses}
        onExit={() => setPresentationMode(false)}
      />
    )
  }

  return (
    <div className="min-h-screen">
      <Header presentationMode={presentationMode} onTogglePresentation={() => setPresentationMode(true)} />

      <main className="max-w-[1600px] mx-auto px-6 py-6 flex flex-col gap-6">
        <StatsBar
          neighborhoodCount={locations.length}
          totalOrders={totalOrders}
          warehouseCount={result ? result.warehouses.length : config.warehouses}
          weightedCost={result ? result.weighted_distance : null}
        />

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3">
            {error}
          </div>
        )}
        {notice && !error && (
          <div className="bg-amber-50 border border-amber-200 text-amber-700 text-sm rounded-xl px-4 py-3">
            {notice}
          </div>
        )}

        <div className="grid lg:grid-cols-[1fr_340px] gap-6">
          <div className="relative h-[520px] card p-2">
            {locations.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center gap-3 text-slate-400 px-8">
                <div className="text-4xl">🗺️</div>
                <p className="text-sm">
                  Load the Bengaluru demo dataset or upload a CSV to see neighborhoods on the map.
                </p>
              </div>
            ) : (
              <>
                <MapView
                  neighborhoods={locations}
                  warehouses={result?.warehouses || []}
                  assignments={result?.assignments || []}
                  showHeatmap={showHeatmap && !result}
                  selectedNeighborhood={selected?.type === 'neighborhood' ? selected.data : null}
                  onSelectNeighborhood={(n, assignment) => setSelected({ type: 'neighborhood', data: n, assignment })}
                  onSelectWarehouse={(w) => setSelected({ type: 'warehouse', data: w })}
                />
                <HeatmapLegend visible={showHeatmap && !result} selected={selected} />
              </>
            )}
          </div>

          <ControlPanel
            config={config}
            setConfig={setConfig}
            onLoadDemo={handleLoadDemo}
            onUploadClick={() => {}}
            onFileSelected={handleFileSelected}
            onOptimize={handleOptimize}
            isOptimizing={isOptimizing}
            dataLoaded={locations.length > 0}
            neighborhoodCount={locations.length}
            showHeatmap={showHeatmap}
            setShowHeatmap={setShowHeatmap}
          />
        </div>

        {result && (
          <>
            <div className="grid lg:grid-cols-[1fr_340px] gap-6">
              <ComparisonChart result={result} />
              <ResultsPanel result={result} />
            </div>

            <WhatIfSimulator locations={locations} config={config} />

            <ExplainabilityPanel result={result} />

            <WarehouseTable
              warehouses={result.warehouses}
              capacity={config.useCapacity ? parseFloat(config.capacity) : null}
              useCapacity={config.useCapacity}
            />

            <AssignmentTable assignments={result.assignments} costPerKm={parseFloat(config.costPerKm) || 25} />
          </>
        )}

        <AlgorithmPanel />

        <footer className="text-center text-xs text-slate-400 pb-6">
          GRIDPOINT — built for a 24-hour hackathon · optimization runs entirely client-requested, server-computed,
          no paid APIs.
        </footer>
      </main>
    </div>
  )
}
