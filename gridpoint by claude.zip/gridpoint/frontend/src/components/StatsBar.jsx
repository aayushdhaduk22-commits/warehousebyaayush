function StatCard({ label, value, sub, accent }) {
  return (
    <div className="card px-5 py-4 flex-1 min-w-[150px]">
      <div className="text-xs font-medium text-slate-400 mb-1">{label}</div>
      <div className={`text-2xl font-extrabold ${accent || 'text-slate-900'}`}>{value}</div>
      {sub && <div className="text-xs text-slate-400 mt-0.5">{sub}</div>}
    </div>
  )
}

export default function StatsBar({ neighborhoodCount, totalOrders, warehouseCount, weightedCost }) {
  return (
    <div className="flex flex-wrap gap-3">
      <StatCard label="Neighborhoods" value={neighborhoodCount} />
      <StatCard label="Daily Orders" value={totalOrders.toLocaleString()} />
      <StatCard label="Warehouses" value={warehouseCount} />
      <StatCard
        label="Weighted Delivery Cost"
        value={weightedCost != null ? `₹${weightedCost.toLocaleString()}` : '—'}
        accent="text-brand-600"
      />
    </div>
  )
}
