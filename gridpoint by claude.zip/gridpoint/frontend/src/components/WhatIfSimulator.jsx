import { useEffect, useState } from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts'
import { runWhatIf } from '../services/api'

export default function WhatIfSimulator({ locations, config }) {
  const [scenarios, setScenarios] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  useEffect(() => {
    if (!locations?.length) return
    let cancelled = false
    setLoading(true)
    setError(null)

    const maxK = Math.min(6, locations.length)
    const range = Array.from({ length: maxK }, (_, i) => i + 1)

    runWhatIf({
      locations,
      warehouse_range: range,
      use_capacity: config.useCapacity,
      capacity: config.useCapacity ? parseFloat(config.capacity) || null : null,
      use_radius: config.useRadius,
      max_radius: config.useRadius ? parseFloat(config.maxRadius) || null : null,
      cost_per_km: parseFloat(config.costPerKm) || 25,
      warehouse_fixed_cost: parseFloat(config.warehouseFixedCost) || 50000,
    })
      .then((data) => {
        if (!cancelled) setScenarios(data.scenarios || [])
      })
      .catch((err) => {
        if (!cancelled) setError(err.message)
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })

    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locations, config.useCapacity, config.capacity, config.useRadius, config.maxRadius, config.costPerKm, config.warehouseFixedCost])

  if (!locations?.length) return null

  const best = scenarios.length ? scenarios.reduce((a, b) => (b.total_cost < a.total_cost ? b : a)) : null

  return (
    <div className="card p-5">
      <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-1">What-If Simulator</h3>
      <p className="text-sm text-slate-500 mb-4">
        See how delivery cost, distance, and infrastructure cost trade off as warehouse count changes. More
        warehouses isn't always better.
      </p>

      {loading && <p className="text-sm text-slate-400">Running scenarios…</p>}
      {error && <p className="text-sm text-red-600">{error}</p>}

      {!loading && scenarios.length > 0 && (
        <>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={scenarios}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="warehouses" tick={{ fontSize: 11 }} label={{ value: 'Warehouses', position: 'insideBottom', offset: -3, fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v) => `₹${Math.round(v).toLocaleString()}`} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="delivery_cost" name="Delivery Cost" stroke="#2c62f5" strokeWidth={2} dot />
                <Line type="monotone" dataKey="warehouse_cost" name="Infra Cost" stroke="#f59e0b" strokeWidth={2} dot />
                <Line type="monotone" dataKey="total_cost" name="Total Cost" stroke="#059669" strokeWidth={3} dot />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 mt-4">
            {scenarios.map((s) => (
              <div
                key={s.warehouses}
                className={`rounded-lg p-2.5 text-center border ${
                  best && s.warehouses === best.warehouses
                    ? 'bg-emerald-50 border-emerald-300'
                    : 'bg-slate-50 border-slate-100'
                }`}
              >
                <div className="text-xs text-slate-400">{s.warehouses} WH</div>
                <div className="text-sm font-bold text-slate-800">
                  ₹{(s.total_cost / 100000).toFixed(2)}L
                </div>
              </div>
            ))}
          </div>

          {best && (
            <p className="text-xs text-slate-500 mt-3">
              Lowest total network cost at <span className="font-semibold text-slate-700">{best.warehouses} warehouses</span> — beyond this point, added infrastructure cost outweighs delivery savings.
            </p>
          )}
        </>
      )}
    </div>
  )
}
