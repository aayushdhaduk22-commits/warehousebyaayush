import { useState } from 'react'

const STEPS = [
  'Collect neighborhood demand',
  'Map geographic locations',
  'Weight locations by order volume',
  'Cluster demand into warehouse zones',
  'Optimize warehouse positions',
  'Assign neighborhoods',
  'Calculate delivery cost',
  'Compare scenarios',
]

export default function AlgorithmPanel() {
  const [open, setOpen] = useState(false)

  return (
    <div className="card p-5">
      <button className="flex items-center justify-between w-full text-left" onClick={() => setOpen((o) => !o)}>
        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400">How GRIDPOINT Works</h3>
        <span className="text-slate-400 text-sm">{open ? '−' : '+'}</span>
      </button>

      {open && (
        <div className="mt-3">
          <div className="flex flex-wrap gap-2">
            {STEPS.map((step, i) => (
              <div key={step} className="flex items-center gap-2">
                <div className="flex items-center gap-2 bg-brand-50 text-brand-700 rounded-full px-3 py-1.5 text-xs font-medium">
                  <span className="w-4 h-4 rounded-full bg-brand-500 text-white flex items-center justify-center text-[10px]">
                    {i + 1}
                  </span>
                  {step}
                </div>
                {i < STEPS.length - 1 && <span className="text-slate-300">→</span>}
              </div>
            ))}
          </div>
          <p className="text-sm text-slate-500 mt-4 leading-relaxed">
            GRIDPOINT uses order-weighted K-Means clustering over Haversine (great-circle) distances. Instead of
            averaging neighborhood coordinates equally, each neighborhood pulls the warehouse centroid toward it in
            proportion to its daily order volume — so a neighborhood with 1,000 orders/day has far more influence
            than one with 50. Multiple random initializations are run and the lowest-cost solution is kept, which
            avoids a single unlucky start producing a weak result.
          </p>
        </div>
      )}
    </div>
  )
}
