export default function HeatmapLegend({ visible, selected }) {
  return (
    <div className="absolute bottom-4 left-4 z-[400] flex flex-col gap-2">
      {visible && (
        <div className="bg-white/95 backdrop-blur rounded-xl shadow-card px-3 py-2.5 text-xs">
          <div className="font-semibold text-slate-600 mb-1.5">Demand Heatmap</div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-3 h-3 rounded-full" style={{ background: '#dc2626' }} />
            <span className="text-slate-500">High demand</span>
          </div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-3 h-3 rounded-full" style={{ background: '#f59e0b' }} />
            <span className="text-slate-500">Medium demand</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full" style={{ background: '#2c62f5' }} />
            <span className="text-slate-500">Low demand</span>
          </div>
        </div>
      )}

      {selected && (
        <div className="bg-white/95 backdrop-blur rounded-xl shadow-card px-3.5 py-3 text-xs max-w-[220px]">
          {selected.type === 'neighborhood' ? (
            <>
              <div className="font-bold text-slate-800 mb-1">{selected.data.name}</div>
              <div className="text-slate-500">Daily Orders: {Math.round(selected.data.daily_orders).toLocaleString()}</div>
              {selected.assignment && (
                <>
                  <div className="text-slate-500">Warehouse: {selected.assignment.warehouse_id}</div>
                  <div className="text-slate-500">Distance: {selected.assignment.distance_km.toFixed(2)} km</div>
                </>
              )}
            </>
          ) : (
            <>
              <div className="font-bold text-slate-800 mb-1">🏭 {selected.data.warehouse_id}</div>
              <div className="text-slate-500">Orders: {Math.round(selected.data.daily_orders).toLocaleString()}</div>
              <div className="text-slate-500">Neighborhoods: {selected.data.assigned_neighborhoods}</div>
              <div className="text-slate-500">Avg distance: {selected.data.avg_distance_km.toFixed(2)} km</div>
            </>
          )}
        </div>
      )}
    </div>
  )
}
