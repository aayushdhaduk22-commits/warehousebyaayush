import { useState, useMemo } from 'react'

const COLUMNS = [
  { key: 'name', label: 'Neighborhood' },
  { key: 'daily_orders', label: 'Orders' },
  { key: 'warehouse_id', label: 'Warehouse' },
  { key: 'distance_km', label: 'Distance' },
  { key: 'delivery_cost', label: 'Delivery Cost' },
  { key: 'status', label: 'Status' },
]

export default function AssignmentTable({ assignments, costPerKm }) {
  const [sortKey, setSortKey] = useState('daily_orders')
  const [sortDir, setSortDir] = useState('desc')

  const rows = useMemo(() => {
    return assignments.map((a) => ({
      ...a,
      delivery_cost: a.distance_km * a.daily_orders * costPerKm,
      status: a.unserved ? 'Unserved' : 'Served',
    }))
  }, [assignments, costPerKm])

  const sorted = useMemo(() => {
    const copy = [...rows]
    copy.sort((a, b) => {
      const av = a[sortKey]
      const bv = b[sortKey]
      if (typeof av === 'string') {
        return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av)
      }
      return sortDir === 'asc' ? av - bv : bv - av
    })
    return copy
  }, [rows, sortKey, sortDir])

  const toggleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortKey(key)
      setSortDir('desc')
    }
  }

  if (!assignments?.length) return null

  return (
    <div className="card p-5 overflow-x-auto">
      <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-3">Neighborhood Assignments</h3>
      <table className="w-full text-sm min-w-[640px]">
        <thead>
          <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
            {COLUMNS.map((col) => (
              <th
                key={col.key}
                className="py-2 pr-4 font-semibold cursor-pointer select-none hover:text-slate-600"
                onClick={() => toggleSort(col.key)}
              >
                {col.label} {sortKey === col.key ? (sortDir === 'asc' ? '↑' : '↓') : ''}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sorted.map((row) => (
            <tr key={row.id} className="border-b border-slate-50 last:border-0">
              <td className="py-2.5 pr-4 font-medium text-slate-800">{row.name}</td>
              <td className="py-2.5 pr-4">{Math.round(row.daily_orders).toLocaleString()}</td>
              <td className="py-2.5 pr-4">{row.warehouse_id}</td>
              <td className="py-2.5 pr-4">{row.distance_km.toFixed(2)} km</td>
              <td className="py-2.5 pr-4">₹{Math.round(row.delivery_cost).toLocaleString()}</td>
              <td className="py-2.5 pr-4">
                <span
                  className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                    row.unserved ? 'bg-red-50 text-red-600' : 'bg-emerald-50 text-emerald-600'
                  }`}
                >
                  {row.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
