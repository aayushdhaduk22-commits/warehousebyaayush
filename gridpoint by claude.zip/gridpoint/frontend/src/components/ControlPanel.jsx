import { useRef } from 'react'

export default function ControlPanel({
  config,
  setConfig,
  onLoadDemo,
  onUploadClick,
  onFileSelected,
  onOptimize,
  isOptimizing,
  dataLoaded,
  neighborhoodCount,
  showHeatmap,
  setShowHeatmap,
}) {
  const fileInputRef = useRef(null)

  const update = (key, value) => setConfig((c) => ({ ...c, [key]: value }))

  return (
    <div className="card p-5 flex flex-col gap-5">
      <div>
        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-2">Data</h3>
        <div className="flex gap-2">
          <button
            className="btn-secondary text-sm flex-1"
            onClick={() => fileInputRef.current?.click()}
          >
            Upload CSV
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv"
            className="hidden"
            onChange={(e) => {
              if (e.target.files?.[0]) onFileSelected(e.target.files[0])
              e.target.value = ''
            }}
          />
          <button className="btn-primary text-sm flex-1" onClick={onLoadDemo}>
            Load Demo Data
          </button>
        </div>
        {dataLoaded && (
          <p className="text-xs text-slate-400 mt-2">{neighborhoodCount} neighborhoods loaded</p>
        )}
        <label className="flex items-center gap-2 mt-3 text-sm text-slate-600 cursor-pointer">
          <input type="checkbox" checked={showHeatmap} onChange={(e) => setShowHeatmap(e.target.checked)} />
          Show demand heatmap
        </label>
      </div>

      <div>
        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-2">Optimization</h3>

        <div className="mb-3">
          <label className="text-sm font-medium text-slate-700 block mb-1">Number of Warehouses</label>
          <div className="flex items-center gap-2">
            <button
              className="btn-secondary w-9 h-9 flex items-center justify-center text-lg"
              onClick={() => update('warehouses', Math.max(1, config.warehouses - 1))}
            >
              −
            </button>
            <div className="flex-1 text-center font-bold text-lg text-slate-800">{config.warehouses}</div>
            <button
              className="btn-secondary w-9 h-9 flex items-center justify-center text-lg"
              onClick={() => update('warehouses', Math.min(10, config.warehouses + 1))}
            >
              +
            </button>
          </div>
        </div>

        <div className="mb-3">
          <label className="flex items-center gap-2 text-sm font-medium text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={config.useCapacity}
              onChange={(e) => update('useCapacity', e.target.checked)}
            />
            Warehouse Capacity Limit
          </label>
          {config.useCapacity && (
            <input
              type="number"
              className="input-field mt-1.5"
              placeholder="e.g. 2000 orders/day"
              value={config.capacity}
              onChange={(e) => update('capacity', e.target.value)}
            />
          )}
        </div>

        <div className="mb-3">
          <label className="flex items-center gap-2 text-sm font-medium text-slate-700 cursor-pointer">
            <input
              type="checkbox"
              checked={config.useRadius}
              onChange={(e) => update('useRadius', e.target.checked)}
            />
            Maximum Service Radius
          </label>
          {config.useRadius && (
            <input
              type="number"
              className="input-field mt-1.5"
              placeholder="e.g. 15 km"
              value={config.maxRadius}
              onChange={(e) => update('maxRadius', e.target.value)}
            />
          )}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div>
            <label className="text-xs font-medium text-slate-500 block mb-1">Cost / km (₹)</label>
            <input
              type="number"
              className="input-field"
              value={config.costPerKm}
              onChange={(e) => update('costPerKm', e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 block mb-1">Warehouse fixed cost (₹/day)</label>
            <input
              type="number"
              className="input-field"
              value={config.warehouseFixedCost}
              onChange={(e) => update('warehouseFixedCost', e.target.value)}
            />
          </div>
        </div>
      </div>

      <button
        className="btn-primary w-full text-sm py-3 disabled:opacity-60"
        onClick={onOptimize}
        disabled={!dataLoaded || isOptimizing}
      >
        {isOptimizing ? 'Optimizing…' : 'OPTIMIZE NETWORK'}
      </button>
    </div>
  )
}
