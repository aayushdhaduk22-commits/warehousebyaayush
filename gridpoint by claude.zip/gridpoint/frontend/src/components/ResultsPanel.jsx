function Row({ label, value, strong, positive }) {
  return (
    <div className="flex items-center justify-between py-1.5">
      <span className="text-sm text-slate-500">{label}</span>
      <span
        className={`text-sm ${strong ? 'font-bold text-slate-900' : 'font-medium text-slate-700'} ${
          positive ? 'text-emerald-600' : ''
        }`}
      >
        {value}
      </span>
    </div>
  )
}

export default function ResultsPanel({ result }) {
  if (!result) {
    return (
      <div className="card p-5 text-sm text-slate-400">
        Run an optimization to see results here.
      </div>
    )
  }

  const inr = (n) => `₹${Math.round(n).toLocaleString('en-IN')}`

  return (
    <div className="card p-5">
      <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-3">Optimization Results</h3>

      {result.capacity_warning && (
        <div className="mb-3 text-xs bg-red-50 text-red-700 border border-red-200 rounded-lg px-3 py-2">
          ⚠️ {result.capacity_warning}
        </div>
      )}
      {result.radius_warning && (
        <div className="mb-3 text-xs bg-red-50 text-red-700 border border-red-200 rounded-lg px-3 py-2">
          ⚠️ {result.radius_warning}
        </div>
      )}

      <Row label="Total Delivery Distance" value={`${result.total_distance.toLocaleString()} km`} />
      <Row label="Weighted Distance" value={`${result.weighted_distance.toLocaleString()} km·orders`} />
      <Row label="Average Distance" value={`${result.avg_distance.toFixed(2)} km`} />
      <div className="border-t border-slate-100 my-2" />
      <Row label="Estimated Delivery Cost" value={inr(result.delivery_cost)} />
      <Row label="Warehouse Cost" value={inr(result.warehouse_cost)} />
      <Row label="Total Network Cost" value={inr(result.total_cost)} strong />
      <div className="border-t border-slate-100 my-2" />
      <Row label="Distance Improvement" value={`${result.improvement_percentage}%`} strong positive />
      <Row label="Cost Improvement" value={`${result.cost_improvement_percentage}%`} strong positive />

      {result.summary?.daily_savings > 0 && (
        <div className="mt-3 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2.5 text-center">
          <div className="text-xs text-emerald-700 font-medium">Estimated Daily Savings</div>
          <div className="text-xl font-extrabold text-emerald-700">{inr(result.summary.daily_savings)}</div>
        </div>
      )}
    </div>
  )
}
