import { MapContainer, TileLayer, CircleMarker, Polyline, Popup, Tooltip } from 'react-leaflet'
import L from 'leaflet'

const BENGALURU_CENTER = [12.9716, 77.5946]

function demandColor(orders, maxOrders) {
  const ratio = maxOrders > 0 ? orders / maxOrders : 0
  if (ratio > 0.66) return '#dc2626' // high - red/orange-ish hot
  if (ratio > 0.33) return '#f59e0b' // medium - amber
  return '#2c62f5' // low - blue
}

function radiusForOrders(orders, maxOrders) {
  const minR = 6
  const maxR = 20
  if (maxOrders <= 0) return minR
  const ratio = Math.sqrt(orders / maxOrders)
  return minR + ratio * (maxR - minR)
}

const warehouseIcon = (label) =>
  L.divIcon({
    className: 'gridpoint-warehouse-icon',
    html: `<div style="
      background:#101828;
      color:white;
      font-weight:700;
      font-size:11px;
      padding:4px 8px;
      border-radius:8px;
      border:2px solid white;
      box-shadow:0 2px 6px rgba(0,0,0,0.35);
      white-space:nowrap;
      transform:translate(-50%,-100%);
    ">🏭 ${label}</div>`,
    iconSize: [0, 0],
    iconAnchor: [0, 0],
  })

export default function MapView({
  neighborhoods,
  warehouses,
  assignments,
  showHeatmap,
  selectedNeighborhood,
  onSelectNeighborhood,
  onSelectWarehouse,
}) {
  const maxOrders = neighborhoods.length ? Math.max(...neighborhoods.map((n) => n.daily_orders)) : 1

  const assignmentByLocId = {}
  assignments.forEach((a) => {
    assignmentByLocId[a.id] = a
  })

  const warehouseColors = ['#2c62f5', '#059669', '#d946ef', '#f59e0b', '#0891b2', '#dc2626', '#7c3aed', '#65a30d']

  return (
    <MapContainer
      center={BENGALURU_CENTER}
      zoom={11}
      scrollWheelZoom={true}
      style={{ height: '100%', width: '100%' }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {/* Connection lines: warehouse -> assigned neighborhood */}
      {assignments.length > 0 &&
        assignments.map((a) => {
          const wh = warehouses[a.warehouse_index]
          if (!wh) return null
          const weight = Math.max(1, Math.min(5, a.daily_orders / 250))
          const color = warehouseColors[a.warehouse_index % warehouseColors.length]
          return (
            <Polyline
              key={`line-${a.id}`}
              positions={[
                [wh.latitude, wh.longitude],
                [a.latitude, a.longitude],
              ]}
              pathOptions={{
                color: a.unserved ? '#dc2626' : color,
                weight,
                opacity: a.unserved ? 0.85 : 0.45,
                dashArray: a.unserved ? '4 4' : null,
              }}
            />
          )
        })}

      {/* Neighborhood markers */}
      {neighborhoods.map((n) => {
        const assignment = assignmentByLocId[n.id]
        const isUnserved = assignment?.unserved
        const baseColor = showHeatmap
          ? demandColor(n.daily_orders, maxOrders)
          : assignment
          ? warehouseColors[assignment.warehouse_index % warehouseColors.length]
          : '#2c62f5'

        return (
          <CircleMarker
            key={n.id}
            center={[n.latitude, n.longitude]}
            radius={radiusForOrders(n.daily_orders, maxOrders)}
            pathOptions={{
              color: isUnserved ? '#dc2626' : '#ffffff',
              weight: selectedNeighborhood?.id === n.id ? 3 : 1.5,
              fillColor: isUnserved ? '#dc2626' : baseColor,
              fillOpacity: 0.85,
            }}
            eventHandlers={{
              click: () => onSelectNeighborhood?.(n, assignment),
            }}
          >
            <Tooltip direction="top" offset={[0, -4]} opacity={0.95}>
              <div className="text-xs">
                <div className="font-semibold">{n.name}</div>
                <div>{Math.round(n.daily_orders).toLocaleString()} orders/day</div>
              </div>
            </Tooltip>
          </CircleMarker>
        )
      })}

      {/* Warehouse markers */}
      {warehouses.map((w, idx) => (
        <CircleMarker
          key={w.warehouse_id}
          center={[w.latitude, w.longitude]}
          radius={12}
          pathOptions={{
            color: 'white',
            weight: 3,
            fillColor: '#101828',
            fillOpacity: 1,
          }}
          eventHandlers={{
            click: () => onSelectWarehouse?.(w),
          }}
        >
          <Tooltip direction="top" offset={[0, -6]} permanent opacity={0.95}>
            <div className="text-[11px] font-bold">🏭 {w.warehouse_id}</div>
          </Tooltip>
          <Popup>
            <div className="text-xs space-y-0.5">
              <div className="font-bold">{w.warehouse_id}</div>
              <div>Location: {w.latitude.toFixed(4)}, {w.longitude.toFixed(4)}</div>
              <div>Assigned orders: {Math.round(w.daily_orders).toLocaleString()}/day</div>
              <div>Neighborhoods: {w.assigned_neighborhoods}</div>
              <div>Avg distance: {w.avg_distance_km} km</div>
            </div>
          </Popup>
        </CircleMarker>
      ))}
    </MapContainer>
  )
}
