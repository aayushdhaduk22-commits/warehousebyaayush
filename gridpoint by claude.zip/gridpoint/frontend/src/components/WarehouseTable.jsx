export default function WarehouseTable({ warehouses, capacity, useCapacity }) {
  if (!warehouses?.length) return null

  return (
    <div className="card p-5 overflow-x-auto">
      <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-3">Warehouse Summary</h3>
      <table className="w-full text-sm min-w-[640px]">
        <thead>
          <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
            <th className="py-2 pr-4 font-semibold">Warehouse</th>
            <th className="py-2 pr-4 font-semibold">Latitude</th>
            <th className="py-2 pr-4 font-semibold">Longitude</th>
            <th className="py-2 pr-4 font-semibold">Neighborhoods</th>
            <th className="py-2 pr-4 font-semibold">Daily Orders</th>
            {useCapacity && <th className="py-2 pr-4 font-semibold">Utilization</th>}
            <th className="py-2 pr-4 font-semibold">Avg Distance</th>
          </tr>
        </thead>
        <tbody>
          {warehouses.map((w) => {
            const utilization = useCapacity && capacity ? (w.daily_orders / capacity) * 100 : null
            return (
              <tr key={w.warehouse_id} className="border-b border-slate-50 last:border-0">
                <td className="py-2.5 pr-4 font-semibold text-slate-800">{w.warehouse_id}</td>
                <td className="py-2.5 pr-4 text-slate-500">{w.latitude.toFixed(4)}</td>
                <td className="py-2.5 pr-4 text-slate-500">{w.longitude.toFixed(4)}</td>
                <td className="py-2.5 pr-4">{w.assigned_neighborhoods}</td>
                <td className="py-2.5 pr-4">{Math.round(w.daily_orders).toLocaleString()}</td>
                {useCapacity && (
                  <td className="py-2.5 pr-4">
                    {utilization != null ? (
                      <span className={utilization > 100 ? 'text-red-600 font-semibold' : 'text-slate-700'}>
                        {utilization.toFixed(1)}%
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>
                )}
                <td className="py-2.5 pr-4">{w.avg_distance_km.toFixed(2)} km</td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
