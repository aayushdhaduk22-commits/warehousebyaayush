export default function Header({ presentationMode, onTogglePresentation }) {
  return (
    <header className="w-full bg-white border-b border-slate-100 sticky top-0 z-20">
      <div className="max-w-[1600px] mx-auto px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-brand-500 flex items-center justify-center text-white font-bold text-lg">
            G
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <h1 className="text-lg font-extrabold tracking-tight text-slate-900">GRIDPOINT</h1>
              <span className="hidden sm:inline text-xs font-medium text-slate-400">
                Warehouse Optimization Platform
              </span>
            </div>
            <p className="hidden md:block text-[11px] text-slate-400 -mt-0.5">
              Smarter Warehouses. Shorter Routes.
            </p>
          </div>
        </div>

        <button onClick={onTogglePresentation} className={presentationMode ? 'btn-primary text-sm' : 'btn-secondary text-sm'}>
          {presentationMode ? 'Exit Presentation Mode' : 'Presentation Mode'}
        </button>
      </div>
    </header>
  )
}
