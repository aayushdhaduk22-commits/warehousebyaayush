import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, CartesianGrid } from 'recharts'

export default function ComparisonChart({ result }) {
  if (!result) return null

  const { before } = result

  const distanceData = [
    { metric: 'Weighted Distance', Before: before.weighted_distance, After: result.weighted_distance },
    { metric: 'Avg Distance (km)', Before: before.avg_distance, After: result.avg_distance },
  ]

  const costData = [
    { metric: 'Delivery Cost (₹)', Before: before.delivery_cost, After: result.delivery_cost },
    { metric: 'Total Network Cost (₹)', Before: before.total_cost, After: result.total_cost },
  ]

  return (
    <div className="card p-5">
      <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400 mb-1">Before vs After</h3>
      <p className="text-sm text-slate-500 mb-4">
        Comparing a naive single central warehouse against GRIDPOINT's optimized network.
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="h-64">
          <p className="text-xs font-semibold text-slate-500 mb-2">Distance</p>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={distanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="metric" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Before" fill="#94a3b8" radius={[6, 6, 0, 0]} />
              <Bar dataKey="After" fill="#2c62f5" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="h-64">
          <p className="text-xs font-semibold text-slate-500 mb-2">Cost</p>
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={costData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="metric" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => `₹${Math.round(v).toLocaleString()}`} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Before" fill="#94a3b8" radius={[6, 6, 0, 0]} />
              <Bar dataKey="After" fill="#059669" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mt-5">
        <div className="bg-slate-50 rounded-xl p-4 text-center">
          <div className="text-xs text-slate-400 font-medium">Cost Reduction</div>
          <div className="text-2xl font-extrabold text-emerald-600">
            ₹{Math.round(result.summary.daily_savings).toLocaleString()}/day
          </div>
        </div>
        <div className="bg-slate-50 rounded-xl p-4 text-center">
          <div className="text-xs text-slate-400 font-medium">Distance Reduction</div>
          <div className="text-2xl font-extrabold text-emerald-600">{result.improvement_percentage}%</div>
        </div>
      </div>
    </div>
  )
}
