import { useState, useMemo } from 'react'

export default function ExplainabilityPanel({ result }) {
  const [open, setOpen] = useState(false)

  const explanations = useMemo(() => {
    if (!result) return []
    const totalOrders = result.assignments.reduce((s, a) => s + a.daily_orders, 0)

    return result.warehouses.map((w) => {
      const members = result.assignments.filter((a) => a.warehouse_id === w.warehouse_id)
      const sortedMembers = [...members].sort((a, b) => b.daily_orders - a.daily_orders)
      const top = sortedMembers.slice(0, 2)
      const topShare = top.reduce((s, m) => s + m.daily_orders, 0)
      const pct = totalOrders > 0 ? ((topShare / totalOrders) * 100).toFixed(0) : 0
      const names = top.map((m) => m.name).join(' and ')

      return {
        id: w.warehouse_id,
        text:
          top.length > 0
            ? `${w.warehouse_id} was pulled toward ${names}, which together generate ${pct}% of total order volume — high-demand neighborhoods exert more influence on where the warehouse centroid lands.`
            : `${w.warehouse_id} serves a lower-demand zone with ${w.assigned_neighborhoods} neighborhoods.`,
      }
    })
  }, [result])

  if (!result) return null

  return (
    <div className="card p-5">
      <button
        className="flex items-center justify-between w-full text-left"
        onClick={() => setOpen((o) => !o)}
      >
        <h3 className="text-xs font-bold uppercase tracking-wide text-slate-400">Why these locations?</h3>
        <span className="text-slate-400 text-sm">{open ? '−' : '+'}</span>
      </button>

      {open && (
        <div className="mt-3 space-y-2.5">
          {explanations.map((e) => (
            <p key={e.id} className="text-sm text-slate-600 leading-relaxed bg-slate-50 rounded-lg p-3">
              {e.text}
            </p>
          ))}
        </div>
      )}
    </div>
  )
}
