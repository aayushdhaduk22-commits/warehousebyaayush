export default function PresentationMode({ result, warehouseCount, onExit }) {
  if (!result) {
    return (
      <div className="fixed inset-0 bg-slate-900 text-white flex flex-col items-center justify-center gap-4 z-50">
        <h1 className="text-4xl font-extrabold">GRIDPOINT</h1>
        <p className="text-slate-300">Run an optimization first to enter presentation mode with results.</p>
        <button className="btn-primary" onClick={onExit}>
          Back
        </button>
      </div>
    )
  }

  return (
    <div className="fixed inset-0 bg-slate-900 text-white flex flex-col items-center justify-center gap-10 z-50 px-6">
      <button
        onClick={onExit}
        className="absolute top-6 right-6 text-slate-400 hover:text-white text-sm border border-slate-700 rounded-lg px-3 py-1.5"
      >
        Exit
      </button>

      <div className="text-center">
        <h1 className="text-5xl font-extrabold tracking-tight mb-2">GRIDPOINT</h1>
        <p className="text-slate-400 text-lg">Warehouse Network Optimization</p>
      </div>

      <div className="flex items-center gap-6 text-slate-300 text-sm sm:text-base">
        <span className="px-4 py-2 rounded-full border border-slate-700">Current Network</span>
        <span className="text-2xl">↓</span>
        <span className="px-4 py-2 rounded-full bg-brand-500 text-white">Optimization Engine</span>
        <span className="text-2xl">↓</span>
        <span className="px-4 py-2 rounded-full border border-slate-700">Optimized Network</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 w-full max-w-3xl">
        <div className="text-center">
          <div className="text-4xl font-extrabold text-emerald-400">{result.improvement_percentage}%</div>
          <div className="text-slate-400 text-sm mt-1">reduction in weighted delivery distance</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-extrabold text-emerald-400">
            ₹{Math.round(result.summary.daily_savings).toLocaleString()}
          </div>
          <div className="text-slate-400 text-sm mt-1">estimated daily savings</div>
        </div>
        <div className="text-center">
          <div className="text-4xl font-extrabold text-brand-400">{warehouseCount}</div>
          <div className="text-slate-400 text-sm mt-1">optimized warehouses</div>
        </div>
      </div>
    </div>
  )
}
