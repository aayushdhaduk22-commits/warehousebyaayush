/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef4ff',
          100: '#d9e6ff',
          200: '#b3ccff',
          300: '#84acff',
          400: '#5285ff',
          500: '#2c62f5',
          600: '#1c46d1',
          700: '#1837a8',
          800: '#172f85',
          900: '#172b6b',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(16,24,40,0.06), 0 1px 3px rgba(16,24,40,0.08)',
        cardHover: '0 4px 12px rgba(16,24,40,0.10)',
      },
    },
  },
  plugins: [],
}
