# GRIDPOINT — Warehouse Location Optimization Platform

**"Where should the warehouse go?"**
*Smarter Warehouses. Shorter Routes.*

GRIDPOINT decides where to place warehouses to minimize weighted delivery
cost across a set of neighborhoods, each with its own order volume. It
solves:

```
minimize  Σ (daily_orders_i × distance_i)
```

using order-weighted K-Means clustering over real geographic (Haversine)
distance — so a neighborhood generating 1,000 orders/day pulls a warehouse
toward it far more than one generating 50/day.

---

## 1. Project Structure

```
gridpoint/
├── backend/
│   ├── main.py          FastAPI app + endpoints
│   ├── optimizer.py      Haversine distance + weighted K-Means + constraints
│   ├── cost.py           Delivery / warehouse / total cost model
│   ├── demo_data.py      Deterministic 25-neighborhood Bengaluru dataset
│   ├── models.py         Pydantic request/response schemas
│   ├── requirements.txt
│   └── sample_data.csv
├── frontend/
│   ├── src/
│   │   ├── components/   Map, control panel, tables, charts, panels
│   │   ├── services/api.js
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
├── sample_data.csv
└── README.md
```

---

## 2. Setup & Run

### Backend (FastAPI)

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python3 -m uvicorn main:app --reload --port 8000
```

Backend runs at **http://localhost:8000**. Interactive API docs at
`http://localhost:8000/docs`.

### Frontend (React + Vite)

```bash
cd frontend
npm install
npm run dev
```

Frontend runs at **http://localhost:5173** and talks to the backend at
`http://localhost:8000` (configurable via `VITE_API_URL` env var, and
proxied through `/api` in `vite.config.js`).

### Fastest way to see it work

1. Start the backend, then the frontend.
2. Open `http://localhost:5173`.
3. Click **"Load Demo Data"**.
4. Leave warehouses at 3 (or adjust) and click **"OPTIMIZE NETWORK"**.
5. Explore the map, before/after chart, tables, What-If Simulator, and
   "Why these locations?" explainability panel.

Total time: under a minute — see `sample_data.csv` for the CSV format if
you want to upload your own data instead.

---

## 3. CSV Format

```
id,name,latitude,longitude,daily_orders
1,Indiranagar,12.9784,77.6408,450
2,Whitefield,12.9698,77.7500,800
```

Uploaded rows are validated server-side (`POST /validate-data`): missing
fields, non-numeric coordinates, out-of-range lat/lon, and negative order
volumes are rejected with a friendly summary rather than crashing the app.

---

## 4. The Optimization Algorithm

**Weighted K-Means** on (latitude, longitude), weighted by `daily_orders`:

1. Initialize K warehouse centers (demand-weighted random sample).
2. Assign every neighborhood to its nearest warehouse by **Haversine
   distance** (great-circle distance, not flat Euclidean — appropriate
   for lat/lon coordinates).
3. Recompute each warehouse's position as the **order-weighted centroid**
   of its assigned neighborhoods:
   ```
   new_lat = Σ(lat_i × orders_i) / Σ(orders_i)
   new_lon = Σ(lon_i × orders_i) / Σ(orders_i)
   ```
4. Repeat until warehouse movement is negligible or max iterations reached.
5. Run this **multiple times with different random initializations**
   (`n_init`, default 8) and keep the lowest-weighted-cost solution — this
   avoids one unlucky random start producing a poor result.

This is implemented from scratch in `backend/optimizer.py` (no black-box
library clustering), so the weighting behavior is fully explainable.

**Capacity constraint** (optional): after clustering, if a warehouse
exceeds its capacity, the lowest-priority neighborhoods are greedily
reassigned to the nearest warehouse with spare capacity. If no feasible
assignment exists, GRIDPOINT reports:
*"Capacity constraint cannot be satisfied with the selected number of
warehouses. Increase warehouse count or capacity."* — without crashing.

**Service radius constraint** (optional): neighborhoods farther than the
max radius from every warehouse are flagged in red on the map and listed
as "Unserved" in the assignment table, with a suggestion to add
warehouses or increase the radius.

---

## 5. Cost Model

```
delivery_cost   = Σ(distance_i × daily_orders_i) × cost_per_km
warehouse_cost  = warehouse_fixed_cost × number_of_warehouses
total_cost      = delivery_cost + warehouse_cost
```

Defaults: `cost_per_km = ₹25`, `warehouse_fixed_cost = ₹50,000/day` — both
configurable in the control panel. The **What-If Simulator** runs this
model across warehouse counts 1–6 to show the trade-off: delivery cost
falls as warehouses increase, but fixed infrastructure cost rises, so
there's a real optimum rather than "more warehouses = always better."

The "before" baseline used for all before/after comparisons is a **single
naive warehouse at the simple (unweighted) geographic centroid** of all
neighborhoods — representing an unoptimized starting point.

---

## 6. API Reference

All endpoints are on the FastAPI backend (`http://localhost:8000`).

### `GET /demo-data`
Returns the built-in 25-neighborhood Bengaluru dataset.

### `POST /validate-data`
```json
{ "rows": [ { "latitude": "12.97", "longitude": "77.64", "daily_orders": "500" } ] }
```
Returns cleaned rows, a list of per-row errors, and a friendly summary.

### `POST /optimize`
```json
{
  "locations": [ { "id": 1, "name": "Indiranagar", "latitude": 12.9784, "longitude": 77.6408, "daily_orders": 620 } ],
  "warehouses": 3,
  "use_capacity": false,
  "capacity": 2000,
  "use_radius": false,
  "max_radius": 15,
  "cost_per_km": 25,
  "warehouse_fixed_cost": 50000
}
```
Returns warehouse locations, per-neighborhood assignments, distances,
costs, before/after comparison, and any constraint warnings.

### `POST /what-if`
Same shape as `/optimize` plus `"warehouse_range": [1,2,3,4,5,6]`. Returns
a cost/distance scenario for each warehouse count in the range, plus the
recommended (lowest total-cost) count.

### `POST /calculate-cost`
Recomputes delivery/warehouse/total cost for a given set of warehouses
and assignments (useful if the frontend wants to re-price without
re-clustering).

---

## 7. Demo Script (for judges)

1. *"We have 25 Bengaluru neighborhoods generating different amounts of
   demand."* → show the map with demand heatmap on.
2. *"GRIDPOINT doesn't treat every neighborhood equally — bigger circles
   mean more daily orders."*
3. *"Let's assume the company wants 3 warehouses."* → set to 3.
4. *"Now let's optimize."* → click **OPTIMIZE NETWORK**.
5. *"The algorithm moved warehouse locations toward the highest-demand
   areas."* → point at the before/after chart and "Why these locations?"
   panel.
6. *"Weighted delivery distance decreased by X%, saving ₹Y/day."*
7. *"What happens if we add a 4th warehouse?"* → open the What-If
   Simulator. *"Delivery cost falls, but infrastructure cost rises — so
   more warehouses isn't automatically better."*
8. Optionally switch to **Presentation Mode** for a clean, judge-facing
   summary screen.

---

## 8. Design Notes & Guardrails

- No paid APIs: map tiles are OpenStreetMap via Leaflet; all optimization
  runs locally in the FastAPI backend using NumPy.
- The demo dataset is fully deterministic (fixed coordinates and order
  volumes, fixed random seed in the optimizer) so every demo run produces
  the same, sensible clustering.
- Every constraint failure (impossible capacity, unreachable radius,
  malformed CSV, too many warehouses) is caught and returned as a
  friendly message — the app never crashes or shows a raw stack trace to
  the user.
- Optimization typically completes in well under a second for 25–500
  neighborhoods on a laptop.
