"""
GRIDPOINT - Warehouse Location Optimization Platform
FastAPI backend entrypoint.

Endpoints:
    GET  /demo-data        -> Bengaluru demo dataset
    POST /validate-data    -> validate uploaded CSV rows
    POST /optimize         -> run the weighted clustering optimization
    POST /what-if          -> evaluate cost/distance across a range of warehouse counts
    POST /calculate-cost   -> compute cost breakdown for a given solution
"""

import math
import traceback

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from models import OptimizeRequest, WhatIfRequest, ValidateRequest, CostRequest
from demo_data import get_demo_data
from optimizer import run_optimization, baseline_single_warehouse_cost, weighted_kmeans, compute_weighted_cost
from cost import total_network_cost, improvement_percentage, delivery_cost_from_weighted_distance, warehouse_cost

app = FastAPI(title="GRIDPOINT API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"status": "ok", "service": "GRIDPOINT API"}


@app.get("/demo-data")
def demo_data():
    return {"locations": get_demo_data()}


@app.post("/validate-data")
def validate_data(payload: ValidateRequest):
    """
    Validates raw CSV rows (as parsed on the frontend) before they are
    used for optimization. Returns cleaned rows plus a list of issues.
    """
    required_fields = ["latitude", "longitude", "daily_orders"]
    valid_rows = []
    errors = []

    for idx, row in enumerate(payload.rows):
        row_num = idx + 1
        missing = [f for f in required_fields if f not in row or row[f] in (None, "")]
        if missing:
            errors.append(f"Row {row_num}: missing field(s) {', '.join(missing)}.")
            continue

        try:
            lat = float(row["latitude"])
            lon = float(row["longitude"])
            orders = float(row["daily_orders"])
        except (ValueError, TypeError):
            errors.append(f"Row {row_num}: latitude/longitude/daily_orders must be numeric.")
            continue

        if math.isnan(lat) or math.isnan(lon) or math.isnan(orders):
            errors.append(f"Row {row_num}: contains invalid (NaN) numeric values.")
            continue

        if not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
            errors.append(f"Row {row_num}: coordinates out of valid range.")
            continue

        if orders < 0:
            errors.append(f"Row {row_num}: daily_orders cannot be negative.")
            continue

        valid_rows.append(
            {
                "id": row.get("id", idx + 1),
                "name": row.get("name", f"Location {idx + 1}"),
                "latitude": lat,
                "longitude": lon,
                "daily_orders": orders,
            }
        )

    is_valid = len(valid_rows) > 0
    summary = None
    if errors:
        summary = f"{len(errors)} row(s) have invalid data and were skipped."

    return {
        "valid": is_valid,
        "rows": valid_rows,
        "errors": errors,
        "summary": summary,
        "row_count": len(valid_rows),
    }


@app.post("/optimize")
def optimize(payload: OptimizeRequest):
    try:
        locations = [loc.dict() for loc in payload.locations]

        if len(locations) == 0:
            return JSONResponse(
                status_code=400,
                content={"error": "No neighborhoods provided. Please upload data or load the demo dataset."},
            )

        if payload.warehouses > len(locations):
            return JSONResponse(
                status_code=400,
                content={
                    "error": f"Cannot create {payload.warehouses} warehouses for only "
                              f"{len(locations)} neighborhoods. Reduce warehouse count."
                },
            )

        result = run_optimization(
            locations,
            k=payload.warehouses,
            use_capacity=payload.use_capacity,
            capacity=payload.capacity,
            use_radius=payload.use_radius,
            max_radius=payload.max_radius,
            n_init=payload.n_init,
        )

        # BEFORE scenario: naive single central warehouse
        lats = [l["latitude"] for l in locations]
        lons = [l["longitude"] for l in locations]
        weights = [l["daily_orders"] for l in locations]
        b_lat, b_lon, b_total, b_weighted, b_avg = baseline_single_warehouse_cost(lats, lons, weights)

        before_costs = total_network_cost(b_weighted, payload.cost_per_km, 1, payload.warehouse_fixed_cost)
        after_costs = total_network_cost(
            result["weighted_distance"], payload.cost_per_km, payload.warehouses, payload.warehouse_fixed_cost
        )

        dist_improvement = improvement_percentage(b_weighted, result["weighted_distance"])
        cost_improvement = improvement_percentage(before_costs["total_cost"], after_costs["total_cost"])
        avg_dist_improvement = improvement_percentage(b_avg, result["avg_distance"])

        total_orders = sum(weights)

        return {
            "warehouses": result["warehouses"],
            "assignments": result["assignments"],
            "total_distance": result["total_distance"],
            "weighted_distance": result["weighted_distance"],
            "avg_distance": result["avg_distance"],
            "delivery_cost": after_costs["delivery_cost"],
            "warehouse_cost": after_costs["warehouse_cost"],
            "total_cost": after_costs["total_cost"],
            "improvement_percentage": dist_improvement,
            "cost_improvement_percentage": cost_improvement,
            "capacity_warning": result["capacity_warning"],
            "radius_warning": result["radius_warning"],
            "n_unserved": result["n_unserved"],
            "before": {
                "warehouse_latitude": round(b_lat, 5),
                "warehouse_longitude": round(b_lon, 5),
                "total_distance": round(b_total, 2),
                "weighted_distance": round(b_weighted, 2),
                "avg_distance": round(b_avg, 3),
                "delivery_cost": before_costs["delivery_cost"],
                "warehouse_cost": before_costs["warehouse_cost"],
                "total_cost": before_costs["total_cost"],
            },
            "summary": {
                "neighborhoods": len(locations),
                "total_daily_orders": total_orders,
                "warehouses": payload.warehouses,
                "distance_improvement_pct": dist_improvement,
                "avg_distance_improvement_pct": avg_dist_improvement,
                "daily_savings": round(before_costs["total_cost"] - after_costs["total_cost"], 2),
            },
        }
    except Exception as exc:  # pragma: no cover - defensive guard for demo stability
        traceback.print_exc()
        return JSONResponse(
            status_code=500,
            content={"error": f"Optimization failed: {str(exc)}. Please check your data and try again."},
        )


@app.post("/what-if")
def what_if(payload: WhatIfRequest):
    """
    Runs the optimizer across a range of warehouse counts so the frontend
    can show how delivery cost, distance and infrastructure cost trade off
    as warehouse count changes.
    """
    try:
        locations = [loc.dict() for loc in payload.locations]
        if len(locations) == 0:
            return JSONResponse(status_code=400, content={"error": "No neighborhoods provided."})

        scenarios = []
        for k in payload.warehouse_range:
            if k < 1 or k > len(locations):
                continue
            result = run_optimization(
                locations,
                k=k,
                use_capacity=payload.use_capacity,
                capacity=payload.capacity,
                use_radius=payload.use_radius,
                max_radius=payload.max_radius,
                n_init=5,
            )
            costs = total_network_cost(
                result["weighted_distance"], payload.cost_per_km, k, payload.warehouse_fixed_cost
            )
            total_orders = sum(l["daily_orders"] for l in locations)
            max_utilization = 0.0
            if result["warehouses"]:
                per_wh_capacity = (payload.capacity if (payload.use_capacity and payload.capacity) else None)
                if per_wh_capacity:
                    max_utilization = round(
                        max(w["daily_orders"] / per_wh_capacity for w in result["warehouses"]) * 100, 1
                    )
            scenarios.append(
                {
                    "warehouses": k,
                    "weighted_distance": result["weighted_distance"],
                    "avg_distance": result["avg_distance"],
                    "delivery_cost": costs["delivery_cost"],
                    "warehouse_cost": costs["warehouse_cost"],
                    "total_cost": costs["total_cost"],
                    "max_utilization_pct": max_utilization,
                    "capacity_warning": result["capacity_warning"],
                    "radius_warning": result["radius_warning"],
                }
            )

        best = min(scenarios, key=lambda s: s["total_cost"]) if scenarios else None

        return {"scenarios": scenarios, "recommended_warehouses": best["warehouses"] if best else None}
    except Exception as exc:  # pragma: no cover
        traceback.print_exc()
        return JSONResponse(status_code=500, content={"error": f"What-if simulation failed: {str(exc)}"})


@app.post("/calculate-cost")
def calculate_cost(payload: CostRequest):
    try:
        weighted_distance = sum(a["distance_km"] * a["daily_orders"] for a in payload.assignments)
        costs = total_network_cost(
            weighted_distance, payload.cost_per_km, len(payload.warehouses), payload.warehouse_fixed_cost
        )
        return {"weighted_distance": round(weighted_distance, 2), **costs}
    except Exception as exc:  # pragma: no cover
        traceback.print_exc()
        return JSONResponse(status_code=500, content={"error": f"Cost calculation failed: {str(exc)}"})


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
