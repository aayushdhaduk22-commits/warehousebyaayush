"""
GRIDPOINT - Deterministic Bengaluru demo dataset.

Coordinates are approximate real-world centroids for each locality.
Order volumes are fixed (not random) so every demo run is reproducible
and produces the same, sensible optimization result.
"""

DEMO_NEIGHBORHOODS = [
    {"id": 1, "name": "Indiranagar", "latitude": 12.9784, "longitude": 77.6408, "daily_orders": 620},
    {"id": 2, "name": "Koramangala", "latitude": 12.9352, "longitude": 77.6245, "daily_orders": 780},
    {"id": 3, "name": "Whitefield", "latitude": 12.9698, "longitude": 77.7500, "daily_orders": 910},
    {"id": 4, "name": "Electronic City", "latitude": 12.8452, "longitude": 77.6602, "daily_orders": 860},
    {"id": 5, "name": "Yelahanka", "latitude": 13.1007, "longitude": 77.5963, "daily_orders": 340},
    {"id": 6, "name": "Hebbal", "latitude": 13.0355, "longitude": 77.5970, "daily_orders": 410},
    {"id": 7, "name": "Jayanagar", "latitude": 12.9299, "longitude": 77.5823, "daily_orders": 530},
    {"id": 8, "name": "JP Nagar", "latitude": 12.9077, "longitude": 77.5851, "daily_orders": 470},
    {"id": 9, "name": "HSR Layout", "latitude": 12.9121, "longitude": 77.6446, "daily_orders": 690},
    {"id": 10, "name": "Marathahalli", "latitude": 12.9591, "longitude": 77.6974, "daily_orders": 730},
    {"id": 11, "name": "BTM Layout", "latitude": 12.9166, "longitude": 77.6101, "daily_orders": 560},
    {"id": 12, "name": "Rajajinagar", "latitude": 12.9915, "longitude": 77.5526, "daily_orders": 380},
    {"id": 13, "name": "Malleshwaram", "latitude": 13.0035, "longitude": 77.5709, "daily_orders": 350},
    {"id": 14, "name": "Banashankari", "latitude": 12.9255, "longitude": 77.5468, "daily_orders": 400},
    {"id": 15, "name": "Bellandur", "latitude": 12.9255, "longitude": 77.6761, "daily_orders": 640},
    {"id": 16, "name": "Sarjapur", "latitude": 12.9010, "longitude": 77.6870, "daily_orders": 480},
    {"id": 17, "name": "KR Puram", "latitude": 12.9930, "longitude": 77.6950, "daily_orders": 390},
    {"id": 18, "name": "Mahadevapura", "latitude": 12.9852, "longitude": 77.6969, "daily_orders": 420},
    {"id": 19, "name": "Ulsoor", "latitude": 12.9816, "longitude": 77.6220, "daily_orders": 310},
    {"id": 20, "name": "Domlur", "latitude": 12.9611, "longitude": 77.6387, "daily_orders": 360},
    {"id": 21, "name": "Vijayanagar", "latitude": 12.9719, "longitude": 77.5350, "daily_orders": 300},
    {"id": 22, "name": "Kengeri", "latitude": 12.9081, "longitude": 77.4855, "daily_orders": 260},
    {"id": 23, "name": "Hosur Road", "latitude": 12.8990, "longitude": 77.6350, "daily_orders": 440},
    {"id": 24, "name": "CV Raman Nagar", "latitude": 12.9836, "longitude": 77.6640, "daily_orders": 280},
    {"id": 25, "name": "Frazer Town", "latitude": 12.9967, "longitude": 77.6120, "daily_orders": 250},
]


def get_demo_data():
    return DEMO_NEIGHBORHOODS
