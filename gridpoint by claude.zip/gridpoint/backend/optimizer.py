"""
GRIDPOINT - Optimization engine.

Implements order-weighted K-Means clustering over geographic coordinates,
using Haversine distance (great-circle distance) rather than Euclidean
distance, since inputs are latitude/longitude pairs.

Objective minimized:
    total_weighted_cost = sum(daily_orders_i * distance_i)

High-demand neighborhoods pull cluster centroids toward them because the
centroid update step weights each point's contribution by its order volume:

    new_lat = sum(lat_i * orders_i) / sum(orders_i)
    new_lon = sum(lon_i * orders_i) / sum(orders_i)

Multiple random initializations are run and the lowest-cost solution is
kept, which avoids a single bad random start producing a poor result.
"""

import numpy as np

EARTH_RADIUS_KM = 6371.0
MAX_ITERATIONS = 100
CONVERGENCE_THRESHOLD_KM = 0.001  # stop when centroid movement is negligible
RANDOM_SEED = 42  # deterministic demo behavior


def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Vectorized Haversine great-circle distance in kilometers.
    lat1, lon1: scalars or arrays (neighborhoods)
    lat2, lon2: scalars or arrays (warehouses)
    Returns an array broadcastable across inputs.
    """
    lat1r, lon1r, lat2r, lon2r = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2r - lat1r
    dlon = lon2r - lon1r
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1r) * np.cos(lat2r) * np.sin(dlon / 2.0) ** 2
    c = 2 * np.arcsin(np.clip(np.sqrt(a), -1, 1))
    return EARTH_RADIUS_KM * c


def _distance_matrix(lats, lons, wh_lats, wh_lons):
    """
    Returns an (n_points, k_warehouses) matrix of Haversine distances.
    """
    lats = np.asarray(lats).reshape(-1, 1)
    lons = np.asarray(lons).reshape(-1, 1)
    wh_lats = np.asarray(wh_lats).reshape(1, -1)
    wh_lons = np.asarray(wh_lons).reshape(1, -1)
    return haversine_distance(lats, lons, wh_lats, wh_lons)


def _run_single_weighted_kmeans(lats, lons, weights, k, rng):
    """
    Single run of weighted K-Means with a random initialization.
    Returns (wh_lats, wh_lons, assignments, weighted_cost).
    """
    n = len(lats)
    k = min(k, n)

    # Initialize centers: pick k distinct points, weighted toward
    # higher-demand neighborhoods so starts are sensible (k-means++-ish).
    probs = weights / weights.sum()
    init_idx = rng.choice(n, size=k, replace=False, p=probs)
    wh_lats = lats[init_idx].copy()
    wh_lons = lons[init_idx].copy()

    assignments = np.zeros(n, dtype=int)

    for _ in range(MAX_ITERATIONS):
        dist = _distance_matrix(lats, lons, wh_lats, wh_lons)  # (n, k)
        new_assignments = np.argmin(dist, axis=1)

        new_wh_lats = wh_lats.copy()
        new_wh_lons = wh_lons.copy()
        for c in range(k):
            mask = new_assignments == c
            if not np.any(mask):
                # Re-seed an empty cluster on the farthest, highest-demand point
                farthest = np.argmax(dist[np.arange(n), new_assignments] * weights)
                new_wh_lats[c] = lats[farthest]
                new_wh_lons[c] = lons[farthest]
                new_assignments[farthest] = c
                mask = new_assignments == c
            w = weights[mask]
            new_wh_lats[c] = np.sum(lats[mask] * w) / np.sum(w)
            new_wh_lons[c] = np.sum(lons[mask] * w) / np.sum(w)

        movement = np.max(
            haversine_distance(wh_lats, wh_lons, new_wh_lats, new_wh_lons)
        )
        wh_lats, wh_lons = new_wh_lats, new_wh_lons
        assignments = new_assignments

        if movement < CONVERGENCE_THRESHOLD_KM:
            break

    final_dist = _distance_matrix(lats, lons, wh_lats, wh_lons)
    point_dist = final_dist[np.arange(n), assignments]
    weighted_cost = float(np.sum(point_dist * weights))

    return wh_lats, wh_lons, assignments, weighted_cost


def weighted_kmeans(lats, lons, weights, k, n_init=8, seed=RANDOM_SEED):
    """
    Runs weighted K-Means multiple times with different random
    initializations and returns the best (lowest weighted-cost) solution.
    """
    lats = np.asarray(lats, dtype=float)
    lons = np.asarray(lons, dtype=float)
    weights = np.asarray(weights, dtype=float)
    weights = np.where(weights <= 0, 0.01, weights)  # guard against zero weight

    rng = np.random.default_rng(seed)

    best = None
    for i in range(max(1, n_init)):
        wh_lats, wh_lons, assignments, cost = _run_single_weighted_kmeans(
            lats, lons, weights, k, rng
        )
        if best is None or cost < best[3]:
            best = (wh_lats, wh_lons, assignments, cost)

    return best  # (wh_lats, wh_lons, assignments, weighted_cost)


def enforce_capacity(lats, lons, weights, assignments, wh_lats, wh_lons, capacity):
    """
    Greedy rebalancing: while any warehouse exceeds capacity, move its
    lowest-priority (cheapest-to-move / lowest order volume among its
    farthest points) neighborhood to the nearest warehouse with spare
    capacity. Returns (assignments, feasible: bool).
    """
    n = len(lats)
    k = len(wh_lats)
    assignments = assignments.copy()
    dist = _distance_matrix(lats, lons, wh_lats, wh_lons)  # (n, k)

    def loads():
        return np.array([weights[assignments == c].sum() for c in range(k)])

    max_iterations = n * k + 50
    it = 0
    while it < max_iterations:
        it += 1
        current_loads = loads()
        overloaded = np.where(current_loads > capacity + 1e-9)[0]
        if len(overloaded) == 0:
            return assignments, True

        wh = overloaded[np.argmax(current_loads[overloaded])]
        members = np.where(assignments == wh)[0]
        if len(members) == 0:
            return assignments, False

        # Candidate to move: the member whose distance-to-current-warehouse
        # penalty is lowest relative to alternatives (cheapest to relocate).
        # Sort members by distance descending (move the "edge" ones first
        # tends to reduce cost impact and helps convergence).
        order = members[np.argsort(-dist[members, wh])]

        moved = False
        for member in order:
            # find nearest warehouse with spare capacity, excluding current
            candidate_order = np.argsort(dist[member])
            for cand in candidate_order:
                if cand == wh:
                    continue
                if current_loads[cand] + weights[member] <= capacity + 1e-9:
                    assignments[member] = cand
                    moved = True
                    break
            if moved:
                break

        if not moved:
            # No feasible move exists anywhere -> infeasible
            return assignments, False

    return assignments, False


def enforce_radius(lats, lons, assignments, wh_lats, wh_lons, max_radius):
    """
    Flags neighborhoods that are farther than max_radius from every
    warehouse (they remain assigned to their nearest warehouse for
    reporting purposes, but are marked as unserved).
    Returns unserved_mask (boolean array).
    """
    dist = _distance_matrix(lats, lons, wh_lats, wh_lons)
    assigned_dist = dist[np.arange(len(lats)), assignments]
    # Could this point be served by ANY warehouse within radius?
    servable_by_any = np.any(dist <= max_radius + 1e-9, axis=1)
    unserved = ~servable_by_any
    # For points servable by some warehouse but not their nearest one,
    # reassign to the nearest warehouse that IS within radius.
    for i in range(len(lats)):
        if not unserved[i] and assigned_dist[i] > max_radius + 1e-9:
            within = np.where(dist[i] <= max_radius + 1e-9)[0]
            if len(within) > 0:
                assignments[i] = within[np.argmin(dist[i, within])]
    return assignments, unserved


def compute_weighted_cost(lats, lons, weights, assignments, wh_lats, wh_lons):
    dist = _distance_matrix(lats, lons, wh_lats, wh_lons)
    point_dist = dist[np.arange(len(lats)), assignments]
    total_distance = float(np.sum(point_dist))
    weighted_distance = float(np.sum(point_dist * weights))
    avg_distance = float(np.mean(point_dist))
    return total_distance, weighted_distance, avg_distance, point_dist


def baseline_single_warehouse_cost(lats, lons, weights):
    """
    'BEFORE' scenario: a single warehouse at the simple (unweighted)
    geographic centroid of all neighborhoods -- representing a naive,
    non-optimized current-state warehouse.
    """
    lats = np.asarray(lats, dtype=float)
    lons = np.asarray(lons, dtype=float)
    weights = np.asarray(weights, dtype=float)
    center_lat = float(np.mean(lats))
    center_lon = float(np.mean(lons))
    dist = haversine_distance(lats, lons, center_lat, center_lon)
    total_distance = float(np.sum(dist))
    weighted_distance = float(np.sum(dist * weights))
    avg_distance = float(np.mean(dist))
    return center_lat, center_lon, total_distance, weighted_distance, avg_distance


def run_optimization(
    locations,
    k,
    use_capacity=False,
    capacity=None,
    use_radius=False,
    max_radius=None,
    n_init=8,
):
    """
    Full optimization pipeline. `locations` is a list of dicts with
    id, name, latitude, longitude, daily_orders.

    Returns a dict describing warehouses, assignments, costs, and any
    constraint warnings.
    """
    n = len(locations)
    lats = np.array([l["latitude"] for l in locations], dtype=float)
    lons = np.array([l["longitude"] for l in locations], dtype=float)
    weights = np.array([l["daily_orders"] for l in locations], dtype=float)

    k = max(1, min(k, n))

    wh_lats, wh_lons, assignments, _ = weighted_kmeans(
        lats, lons, weights, k, n_init=n_init
    )

    capacity_warning = None
    radius_warning = None
    unserved_mask = np.zeros(n, dtype=bool)

    if use_capacity and capacity:
        assignments, feasible = enforce_capacity(
            lats, lons, weights, assignments, wh_lats, wh_lons, capacity
        )
        if not feasible:
            capacity_warning = (
                "Capacity constraint cannot be satisfied with the selected "
                "number of warehouses. Increase warehouse count or capacity."
            )
        # Recompute warehouse centers as weighted centroids of final assignment
        for c in range(k):
            mask = assignments == c
            if np.any(mask):
                w = weights[mask]
                wh_lats[c] = np.sum(lats[mask] * w) / np.sum(w)
                wh_lons[c] = np.sum(lons[mask] * w) / np.sum(w)

    if use_radius and max_radius:
        assignments, unserved_mask = enforce_radius(
            lats, lons, assignments, wh_lats, wh_lons, max_radius
        )
        n_unserved = int(np.sum(unserved_mask))
        if n_unserved > 0:
            radius_warning = (
                f"{n_unserved} neighborhood(s) cannot currently be served "
                f"within the selected radius. Suggest increasing warehouse "
                f"count or service radius."
            )

    total_distance, weighted_distance, avg_distance, point_dist = compute_weighted_cost(
        lats, lons, weights, assignments, wh_lats, wh_lons
    )

    warehouses = []
    for c in range(k):
        mask = assignments == c
        assigned_orders = float(weights[mask].sum())
        n_neighborhoods = int(np.sum(mask))
        avg_wh_distance = float(point_dist[mask].mean()) if n_neighborhoods > 0 else 0.0
        warehouses.append(
            {
                "warehouse_id": f"WH-{c + 1:02d}",
                "latitude": round(float(wh_lats[c]), 5),
                "longitude": round(float(wh_lons[c]), 5),
                "assigned_neighborhoods": n_neighborhoods,
                "daily_orders": round(assigned_orders, 1),
                "avg_distance_km": round(avg_wh_distance, 2),
            }
        )

    assignment_rows = []
    for i, loc in enumerate(locations):
        assignment_rows.append(
            {
                "id": loc["id"],
                "name": loc["name"],
                "latitude": loc["latitude"],
                "longitude": loc["longitude"],
                "daily_orders": loc["daily_orders"],
                "warehouse_id": warehouses[assignments[i]]["warehouse_id"],
                "warehouse_index": int(assignments[i]),
                "distance_km": round(float(point_dist[i]), 3),
                "unserved": bool(unserved_mask[i]),
            }
        )

    return {
        "warehouses": warehouses,
        "assignments": assignment_rows,
        "total_distance": round(total_distance, 2),
        "weighted_distance": round(weighted_distance, 2),
        "avg_distance": round(avg_distance, 3),
        "capacity_warning": capacity_warning,
        "radius_warning": radius_warning,
        "n_unserved": int(np.sum(unserved_mask)),
    }
