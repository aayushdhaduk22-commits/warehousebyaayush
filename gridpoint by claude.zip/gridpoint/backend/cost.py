"""
GRIDPOINT - Cost model.

delivery_cost   = sum(distance_i * daily_orders_i) * cost_per_km
warehouse_cost  = warehouse_fixed_cost * number_of_warehouses
total_cost      = delivery_cost + warehouse_cost
"""


def delivery_cost_from_weighted_distance(weighted_distance, cost_per_km):
    """weighted_distance = sum(distance_i * orders_i) in km*orders units."""
    return weighted_distance * cost_per_km


def warehouse_cost(num_warehouses, warehouse_fixed_cost):
    return num_warehouses * warehouse_fixed_cost


def total_network_cost(weighted_distance, cost_per_km, num_warehouses, warehouse_fixed_cost):
    delivery = delivery_cost_from_weighted_distance(weighted_distance, cost_per_km)
    infra = warehouse_cost(num_warehouses, warehouse_fixed_cost)
    return {
        "delivery_cost": round(delivery, 2),
        "warehouse_cost": round(infra, 2),
        "total_cost": round(delivery + infra, 2),
    }


def improvement_percentage(before_value, after_value):
    if before_value <= 0:
        return 0.0
    return round(((before_value - after_value) / before_value) * 100, 2)
