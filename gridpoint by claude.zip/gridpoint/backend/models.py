"""
GRIDPOINT - Pydantic models for API requests and responses.
"""
from pydantic import BaseModel, Field
from typing import List, Optional


class NeighborhoodIn(BaseModel):
    id: int
    name: str
    latitude: float
    longitude: float
    daily_orders: float


class OptimizeRequest(BaseModel):
    locations: List[NeighborhoodIn]
    warehouses: int = Field(ge=1, le=15)
    use_capacity: bool = False
    capacity: Optional[float] = None
    use_radius: bool = False
    max_radius: Optional[float] = None
    cost_per_km: float = 25.0
    warehouse_fixed_cost: float = 50000.0
    n_init: int = 8


class WhatIfRequest(BaseModel):
    locations: List[NeighborhoodIn]
    warehouse_range: List[int] = [1, 2, 3, 4, 5, 6]
    use_capacity: bool = False
    capacity: Optional[float] = None
    use_radius: bool = False
    max_radius: Optional[float] = None
    cost_per_km: float = 25.0
    warehouse_fixed_cost: float = 50000.0


class ValidateRequest(BaseModel):
    rows: List[dict]


class CostRequest(BaseModel):
    locations: List[NeighborhoodIn]
    warehouses: List[dict]
    assignments: List[dict]
    cost_per_km: float = 25.0
    warehouse_fixed_cost: float = 50000.0
